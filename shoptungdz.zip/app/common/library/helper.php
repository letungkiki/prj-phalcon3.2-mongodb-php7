<?php

class Helper extends \Phalcon\DI\Injectable
{
    var $facebook;

    public function getLopHoc()
    {
        $user = $this->session->get('user');

        $phancong = \PhanCongGiangDay::find(array(
           'conditions' => array(
               'truonghoc_id' => $user->managed_id,
               'namhoc' => $user->namhoc,
               'nhanvien_id' => $user->nhanvien_id,
           )
        ));


        $lophoc_ids = array();
        foreach($phancong as $k => $v){
            foreach($v->monhoc_ids as $v1){
                $lophoc_ids[(string)$v->lophoc_id][]=$v1 ;
            }

        }
        return $lophoc_ids;
    }
    public function getLopHocs()
    {
        if(!empty($this->session->get('user')->lophoc_ids)){
            foreach($this->session->get('user')->lophoc_ids as $k=>$v){
                $lophoc_ids[]=!empty($k)?\LopHoc::findById($k)->_id:null;
            }

            $lophocs=\LopHoc::find(array(
                'conditions' => array(
                    'truonghoc_id' => $this->session->get('user')->managed_id,
                    'namhoc' => $this->session->get('user')->namhoc,
                    '_id'=>array('$in'=>$lophoc_ids),
                ),
                'sort'=>array('tenlophoc'=>1),
            ));
        }
        else if($this->session->get('user')->taikhoanchinh)
        {
            $lophocs=\LopHoc::find(array(
                'conditions' => array(
                    'truonghoc_id' => $this->session->get('user')->managed_id,
                    'namhoc' => $this->session->get('user')->namhoc,
                ),
                'sort'=>array('tenlophoc'=>1),
            ));
        }
        return $lophocs;
    }
    public function getMonHoc($lophoc_id)
    {
        $lophoc=\LopHoc::findById($lophoc_id);
        $result=new stdClass();
        $result->moncodanhgias=array();
        $result->moncobaikiemtras=array();
        $result->monchixepthoikhoabieus=array();
        $monhoctheokhoi=\MonHocTheoKhoi::findFirst(array(
            'conditions'=>array(
                'khoilop_id'=>$lophoc->khoilop_id
            )
        ));
        foreach($lophoc->monhocs as $k=>$v){
            if(in_array($v,$monhoctheokhoi->congtacdanhgias)){
                $result1=new stdClass();
                $result1->monhoc_id=$v;
                if(!empty($monhoctheokhoi->sotiettuans[$v])){
                    $result1->sotiettuan=$monhoctheokhoi->sotiettuans[$v];
                }
                $result->moncodanhgias[]=$result1;
            }
            if(in_array($v,$monhoctheokhoi->cobaikiemtras)){
                $result1=new stdClass();
                $result1->monhoc_id=$v;
                if(!empty($monhoctheokhoi->sotiettuans[$v])){
                    $result1->sotiettuan=$monhoctheokhoi->sotiettuans[$v];
                }
                $result->moncobaikiemtras[]=$result1;
            }
            if(in_array($v,$monhoctheokhoi->hienxepthoikhoabieus)){
                $result1=new stdClass();
                $result1->monhoc_id=$v;
                if(!empty($monhoctheokhoi->sotiettuans[$v])){
                    $result1->sotiettuan=$monhoctheokhoi->sotiettuans[$v];
                }
                $result->monchixepthoikhoabieus[]=$result1;
            }
        }
        return $result;
    }
    public function getLop($hocsinh_id)
    {
       $lophocs=\LopHoc::find(array(
           'conditions'=>array(
               'truonghoc_id'=>$this->session->get('user')->managed_id,
               'namhoc'=>$this->session->get('user')->namhoc,
           ),
           'sort'=>array('tenlophoc'=>1),
       ));
        foreach($lophocs as $k=>$v){
            if(in_array($hocsinh_id,$v->hocsinh_ids)){
                $lophoc=$lophocs[$k];
            }
        }
        return $lophoc;
    }

    public function setLog($content, $type='khongphanloai')
    {
        $doc= new \Logs();
        $doc->namhoc= $this->session->get('user')->namhoc;
        $doc->managed_id= $this->session->get('user')->managed_id; //id cua cap gui
        $doc->users_id= $this->session->get('user')->_id;
        $doc->content= $content;
        $doc->type= $type;
        $doc->loged= new \MongoDB\BSON\UTCDateTime(time()*1000);
        if($doc->save()){

        }else{
//            var_dump($doc);
            die;
        }
    }

    public function sendNotify($message, $type, $user_id,$namhoc,$managed_id){
        $doc= new \Notifies();
        $doc->namhoc= $namhoc;
        $doc->user_id= $user_id;
        $doc->managed_id= $managed_id; //id cua cap gui
        $doc->message= $message;
        $doc->type= $type;
        $doc->status= 0;
        $doc->state_device= false;
        $doc->notified= new \MongoDB\BSON\UTCDateTime(time()*1000);
        if($doc->save()){
            $message= urlencode($message);
            $url= $this->config->notify.'?message='.$message.'&type='.$type.'&id='.$doc->_id.'&managed_id='.$managed_id;
            $this->getWebPage($url);
        }else{
            die;
        }
    }


    public function fireNotify($user_id){

        $user = \Users::findById($user_id);
        $token_device = $user->token_device;

        if(!empty($token_device)){
            define("GOOGLE_API_KEY", $this->config->apiKey);
            define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");

            $notifies = \Notifies::find(array(
                'conditions' => array(
                    'user_id' => $user->_id,
                    'state_device' => false
                )

            ));

            foreach ($notifies as $k => $doc){
                $title = $doc->type;
                $message = $doc->message;
                $fields = array(
                    //'registration_ids' =>  array($reg_id),
                    'to'  						=> $token_device,
                    'priority'					=> 'normal',//"high",
                    'notification'              => array( "title"=>$title, "body" => $message ),
                );

                //echo "<br>";
                //echo json_encode($fields);
                //echo "<br>";

                $headers = array(
                    'Authorization: key=' . GOOGLE_API_KEY,
                    'Content-Type: application/json'
                );

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

                $result = curl_exec($ch);
                if ($result === FALSE) {
                    die('Problem occurred: ' . curl_error($ch));
                }
                else{
                    $doc->state_device = true;
                    $doc->save();
                }


                curl_close($ch);
            }
        }
//        return $result;
        return json_decode($result);die;
    }


    public function updateFirebase($key, $value, $defaultPath='/thongbao/'){
        try
        {
            $firebase = new \Firebase\FirebaseLib($this->config->urlFire, $this->config->databaseSecrets);
            $firebase->set($defaultPath . $key, $value);
            return true;
        }
        catch (Exception $e)
        {
            return $e;
        }
        return false;
    }

    public function getFirebase($key,$defaultPath='/thongbao/')
    {
        try
        {
            $firebase = new \Firebase\FirebaseLib($this->config->urlFire, $this->config->databaseSecrets);
            $val = $firebase->get($defaultPath . $key);
            return $val;
        }
        catch (Exception $e)
        {
            return false;
        }
        return false;

    }

    public function isDuplicate($model, $fields, $doc)
    {
        $model= '\\'.ucfirst($model);

        $conditions= array(
            '_id' => array('$ne' => $doc->getId())
        );

        if(is_string($fields)){
            $fields= array($fields);
        }

        if(is_array($fields)){
            foreach($fields as $field){
                $value= $doc->{$field};
                if(is_string($value)){
                    $value= trim($value);
                    $conditions[$field]= new \MongoDB\BSON\Regex('^'.$value,'i');
                }else{
                    $conditions[$field]= $value;
                }
            }
        }
        //array($field => new \MongoRegex('/^'.$doc->{$field}.'$/i'), )

        $dup= $model::findFirst(array(
            'conditions' => $conditions
        ));

        if(!empty($dup)){
            return true;
        }else{
            return false;
        }
    }

    function getUrl()
    {
        $s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : ""; $protocol = substr(strtolower($_SERVER["SERVER_PROTOCOL"]), 0, strpos(strtolower($_SERVER["SERVER_PROTOCOL"]), "/")).$s; $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);

        return $protocol."://".$_SERVER['SERVER_NAME'].$port.$_SERVER['REQUEST_URI'];
    }

    function getEXT($filename= "")
    {
        return strtolower(end(explode(".", $filename)));
    }

    function getFilename($url, $getEXT=false){
        $arr= explode('?', $url);
        $url= $arr[0]; //loai bo query_string

        $arr= explode('/', $url);

        if($arr){
            if($getEXT){
                return $this->getEXT($arr[count($arr)-1]);
            }else{
                return $arr[count($arr)-1];
            }
        }
    }

    function getImageFolder($date='')
    {
        $path= '';

        $path.= $this->config->media->folder.'images/';
        if(!is_dir($path)){
            mkdir($path);
        }

        if(empty($date)){
            $date= time();
        }
        $arr= explode('-', date('Y-m-d', $date));

        $path.= $arr[0].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        $path.= $arr[1].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        $path.= $arr[2].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        return str_replace($this->config->media->folder, '', $path);
    }
    function getWordFolder($date='')
    {
        $path= '';

        $path.= $this->config->media->folder.'word/';
        if(!is_dir($path)){
            mkdir($path);
        }

        if(empty($date)){
            $date= time();
        }
        $arr= explode('-', date('Y-m-d', $date));

        $path.= $arr[0].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        $path.= $arr[1].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        $path.= $arr[2].'/';
        if(!is_dir($path)){
            mkdir($path);
        }

        return str_replace($this->config->media->folder, '', $path);
    }

    public function saveTags($tags)
    {
        if(!empty($tags))
        {
            if(!is_array($tags)){
                $tags= explode(",", $tags);
            }

            foreach($tags as $tag)
            {
                $tag= trim($tag);
                if(!empty($tag)) {
                    $slug= $this->helper->createSlug($tag);

                    $doc= \Tag::findFirst(array(
                        'conditions' => array('slug' => $slug)
                    ));
                    //var_dump($doc); die();

                    if(empty($doc)) {
                        $doc= new \Tag();
                        $doc->title= ucfirst($tag);
                        $doc->slug= $slug;

                        $doc->save();
                    }
                }
            }
        }
    }

    public function getWidget($controller, $action, $params){
        $class= '\Frontend\Controllers\\'.ucfirst($controller).'Controller';
        $obj= new $class;

        $widget= $action.'Widget';
        $obj->{$widget}($params);
    }

    public function getUploadFolder($type= ''){
        if(strpos($type, '/')===false){
            $type.= '/';
        }

        $folder= $this->config->application->imagesFolder.$type;
        if(!is_dir($folder)){
            mkdir($folder);
        }

        $folder.= date('Y').'/';
        if(!is_dir($folder)){
            mkdir($folder);
        }

        $folder.= date('m').'/';
        if(!is_dir($folder)){
            mkdir($folder);
        }

        $folder.= date('d').'/';
        if(!is_dir($folder)){
            mkdir($folder);
        }

        return $type.date('Y/m/d/');
    }

    public function saveData(&$doc, $fields= array())
    {
        if(!empty($fields)){
            foreach($fields as $field){
                if($field=='views'){
                    $doc->{$field}++;
                    $doc->save();
                }
            }
        }
    }

    public function setData(&$docs, $model='')
    {
        $array= array();
        if(is_object($docs)){
            $array[]= $docs;
        }elseif(is_array($docs)){
            $array= $docs;
        }

        if(empty($array[0])){
            return false;
        }

        $model= get_class($array[0]);

        if($model=='Videos'){
            foreach($array as $doc){
                $doc->idol = $this->helper->idToObject('Idols', $doc->idols_id);
                $doc->idol->link= $this->url->getBaseUri().$doc->idol->alias;
                $doc->idol->avatar= $this->config->url->images.'idol/avatar/'.$doc->idol->avatar;

                $doc->link= $this->url->getBaseUri().$doc->alias.'.html';
                $doc->icon= $this->config->url->images.'crop/100x75/video/'.$doc->image;
                $doc->thumb= $this->config->url->images.'crop/317x237/video/'.$doc->image;
                $doc->playImage= $this->config->url->images.'crop/644x364/video/'.$doc->image;
                $doc->image= $this->config->url->images.'video/'.$doc->image;
            }
        }elseif($model=='Idols'){
            foreach($array as $doc){
                $doc->link= $this->url->getBaseUri().$doc->alias;
                $doc->title= str_replace('"', '&quote;', $doc->title);

                $doc->seo_title= $doc->title.' CCTalk IDOL '.$this->removeMarks($doc->title);
                $doc->seo_description= "Tổng hợp thông tin về Idol ".$doc->title." trên ccTalk. Lịch biểu diễn, video clip, show talk, tin tức hoạt động của ".$doc->title;

                $doc->icon= $this->config->url->images.'crop/32x32/idol/avatar/'.$doc->avatar;
                $doc->avatar= $this->config->url->images.'idol/avatar/'.$doc->avatar;
                $doc->cover= $this->config->url->images.'idol/cover/'.$doc->cover;

                $doc->videos= \Videos::count(array(
                    'conditions' => array('idols_id' => $doc->getId())
                ));
            }
        }elseif($model=='News'){
            foreach($array as $doc){
                $doc->link= $this->url->getBaseUri().$doc->alias.'.html';
                $doc->title= str_replace('"', '&quote;', $doc->title);

                $doc->seo_title= $doc->title;
                $doc->seo_description= $doc->intro;

                $doc->image= $this->config->url->images.''.$doc->image;
            }
        }elseif($model=='Photos'){
            foreach($array as $doc){
                $doc->link= $this->url->get('photos/').$doc->alias.'.html';
                $doc->title= str_replace('"', '&quote;', $doc->title);

                $doc->seo_title= $doc->title;
                $doc->seo_description= $doc->intro;

                $doc->thumb= $this->config->url->images.'resize/290x0/'.$doc->image;
                $doc->image= $this->config->url->images.''.$doc->image;
            }
        }
    }

    public function cropImage($src, $width= 0, $height= 0, $des= ''){
        if($des==''){
            $des= $src;
        }

        if($src!='' && $width>0 && $height>0){
            if(!class_exists('imageTransform')){
                include($this->config->application->libraryDir.'imageTransform.php');
            }
            $imageTransform= new \imageTransform();
            //var_dump($imageTransform); die();
            $imageTransform->crop($src, $width, $height, $des);
        }
    }

    public function __construct(){
        /*$config = array(
            'appId' => $this->config->facebook->app_id,
            'secret' => $this->config->facebook->app_secret,
            //'cookie' => true,
        );
        $this->facebook = new \Facebook($config);*/
    }

    function parseYoutube($url) {
        parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
        if(isset($my_array_of_vars['v'])){
            $row= array();
            $row['id']= $my_array_of_vars['v'];
            $row['image']= "http://img.youtube.com/vi/{$row['id']}/0.jpg";

            return $row;
        }else{
            return false;
        }
    }

    function getRedirectUrl($url){
        stream_context_set_default(array(
            'http' => array(
                'method' => 'HEAD'
            )
        ));
        $headers = get_headers($url, 1);
        if ($headers !== false && isset($headers['Location'])) {
            return $headers['Location'];
        }
        return $url;
    }

    function getWebPage($url, $post_var="")
    {
        //$url= $this->getRedirectUrl($url);

        $userAgent = 'Mozilla/4.0';
        $options = array(
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 20,      // timeout on connect
            CURLOPT_TIMEOUT        => 20,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
            CURLOPT_USERAGENT		=> $userAgent
        );

        if($post_var!="")
        {
            $options[CURLOPT_POST]= 1;
            $options[CURLOPT_POSTFIELDS]= $post_var;
        }


        $ch      = curl_init( $url );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );

        $header['errno']   = $err;
        $header['errmsg']  = $errmsg;
        $header['content'] = $content;

        return $content;
    }

    public function getDate(){
        $date= date('Y-m-d');
        return $this->toSystemDate($date);
    }

    public function getDatetime(){
        $datetime= date('Y-m-d H:i:s');
        return $this->toSystemDate($datetime);
    }

    public function toSystemDate($datetime=''){
        if(!empty($datetime)) {
            $datetime = explode(' ', $datetime);
            $arr= explode($this->config->format->date_pos['separate'], $datetime[0]);
            if(empty($datetime[1])){
                $datetime[1]= '00:00:00';
            }

            $isoDate= new DateTime($arr[$this->config->format->date_pos['Y']].'-'.$arr[$this->config->format->date_pos['m']].'-'.$arr[$this->config->format->date_pos['d']].'T'.$datetime[1].'Z');


            $dateTemp = new  MongoDB\BSON\UTCDateTime($isoDate->getTimestamp()*1000);

            return $dateTemp;
        }else{
            return null;
        }
    }

    public function displayDate($mongoDate){
        if(!empty($mongoDate)){
            //toDateTime()->format($this->config->format->date)
            return $mongoDate->toDateTime()->format($this->config->format->date);
        }else{
            return '';
        }
    }

    public function toDisplayDate($mongoDate){
        return $this->displayDate($mongoDate);
    }

    public function displayDatetime($mongoDate){
        if(!empty($mongoDate)){
            return date($this->config->format->datetime, $mongoDate->sec);
        }else{
            return '';
        }
    }

    public function toDisplayDatetime($mongoDate){
        return $this->displayDatetime($mongoDate);
    }

    public function setRedis($doc){
        //start: luu redis
        $redis = new \Redis();
        $redis->connect('192.168.1.23', 6379, 1, NULL, 100); // 1 sec timeout, 100ms delay between reconnection attempts.
        //print_r($redis);
        $key= '/mememedia/'.$doc->src;
        $value= $this->config->application->videosFolder.$doc->src;
        $redis->set($key, $value);
        $redis->save();
        // end: luu redis
    }

    public function setConvert(&$doc){
        /* start convert */
        $arr= explode('.',  $doc->src);
        $arr= explode('/',  $arr[0]);

        $folder_count= $arr[0];
        $uploadFolder= "{$folder_count}/";
        $vid= $arr[1];

        //ko co vid thi khong lam j
        if(empty($vid))
            return '';

        //xoa convert cu neu la edit
        if(isset($doc->converts) && is_array($doc->converts)){
            foreach($doc->converts as $convert){
                @unlink($this->config->application->videosFolder.str_replace(".mp4", "-".$convert['quality'].".mp4", $doc->src));
                @unlink($this->config->application->storesFolder.str_replace(".mp4", "-".$convert['quality'].".mp4", $doc->src));
            }
        }

        $doc->converts = array();

        if(!is_dir($this->config->application->videosFolder."convert")){
            mkdir($this->config->application->videosFolder."convert");
        }

        $qualities= array(
            '360' => 600,
            '480' => 1000,
            '720' => 2500,
            '1080' => 4000
        );

        //convert origin
        $bitrate= 0;
        foreach($qualities as $qk=>$qv){
            if( $doc->height <= $qk && ($doc->bitrate/1024) > ($qv+100) ){
                $bitrate= $qv;
                break;
            }
        }

        if($bitrate>0){

            $stringData = "/opt/ffmpeg/bin/ffmpeg -y -i {input} -vcodec libx264 -threads 8 -profile baseline -vb ".$bitrate."k -f mp4 {output}"; //-acodec libfaac -ab 128k
            $stringData = str_replace("{input}", $this->config->application->videosFolder.$doc->src, $stringData);
            $stringData = str_replace("{output}", $this->config->application->videosFolder.$uploadFolder.$vid."-o.mp4", $stringData);

            $myFile = $this->config->application->videosFolder."convert/".$folder_count."-".$vid."-o.txt";
            $fh = fopen($myFile, 'w');
            fwrite($fh, $stringData."\n");
            fclose($fh);

            $doc->converts[]= array(
                'quality' => 'o',
                'state' => 0
            );
        }

        //convert 360
        if($doc->height > 360){

            $stringData = "/opt/ffmpeg/bin/ffmpeg -y -i {input} -vcodec libx264 -threads 8 -profile baseline -vb 600k -vf scale='trunc(oh*a/2)*2:360' -f mp4 {output}";

            $stringData = str_replace("{input}", $this->config->application->videosFolder.$doc->src, $stringData);
            $stringData = str_replace("{output}", $this->config->application->videosFolder.$uploadFolder.$vid."-360.mp4", $stringData);

            $myFile = $this->config->application->videosFolder."convert/".$folder_count."-".$vid."-360.txt";
            $fh = fopen($myFile, 'w');
            fwrite($fh, $stringData."\n");
            fclose($fh);

            $doc->converts[]= array(
                'quality' => '360',
                'state' => 0
            );
        }

        //convert 480
        if($doc->height > 480){

            $stringData = "/opt/ffmpeg/bin/ffmpeg -y -i {input} -vcodec libx264 -threads 8 -profile baseline -vb 1000k -vf scale='trunc(oh*a/2)*2:480' -f mp4 {output}";

            $stringData = str_replace("{input}", $this->config->application->videosFolder.$doc->src, $stringData);
            $stringData = str_replace("{output}", $this->config->application->videosFolder.$uploadFolder.$vid."-480.mp4", $stringData);

            $myFile = $this->config->application->videosFolder."convert/".$folder_count."-".$vid."-480.txt";
            $fh = fopen($myFile, 'w');
            fwrite($fh, $stringData."\n");
            fclose($fh);

            $doc->converts[]= array(
                'quality' => '480',
                'state' => 0
            );
        }

        //convert 720
        if($doc->height > 720){

            $stringData = "/opt/ffmpeg/bin/ffmpeg -y -i {input} -vcodec libx264 -threads 8 -profile baseline -vb 2500k -vf scale='trunc(oh*a/2)*2:720' -f mp4 {output}";

            $stringData = str_replace("{input}", $this->config->application->videosFolder.$doc->src, $stringData);
            $stringData = str_replace("{output}", $this->config->application->videosFolder.$uploadFolder.$vid."-720.mp4", $stringData);

            $myFile = $this->config->application->videosFolder."convert/".$folder_count."-".$vid."-720.txt";
            $fh = fopen($myFile, 'w');
            fwrite($fh, $stringData."\n");
            fclose($fh);

            $doc->converts[]= array(
                'quality' => '720',
                'state' => 0
            );
        }

        //convert 1080
        if($doc->height > 1080){

            $stringData = "/opt/ffmpeg/bin/ffmpeg -y -i {input} -vcodec libx264 -threads 8 -profile baseline -vb 2500k -vf scale='trunc(oh*a/2)*2:1080' -f mp4 {output}";

            $stringData = str_replace("{input}", $this->config->application->videosFolder.$doc->src, $stringData);
            $stringData = str_replace("{output}", $this->config->application->videosFolder.$uploadFolder.$vid."-1080.mp4", $stringData);

            $myFile = $this->config->application->videosFolder."convert/".$folder_count."-".$vid."-1080.txt";
            $fh = fopen($myFile, 'w');
            fwrite($fh, $stringData."\n");
            fclose($fh);

            $doc->converts[]= array(
                'quality' => '1080',
                'state' => 0
            );
        }
        /*end convert */
    }

    /*public function getExt($filename){
        $ext= explode(".", $filename);
        $ext= '.'.strtolower($ext[count($ext)-1]);
        return $ext;
    }*/

    public function getFolderCount($subDir)
    {
        $folder_config= Configs::findFirst(array("conditions" => array("code" => "folder_count_".$subDir)));
        if(!$folder_config){
            $folder_config= new Configs();
            $folder_config->code= "folder_count_".$subDir;
            $folder_config->value= 1;
        }
        $folder_count= $folder_config->value!=''?$folder_config->value:1;

        $file_config= Configs::findFirst(array("conditions" => array("code" => "file_count_".$subDir)));
        if(!$file_config){
            $file_config= new Configs();
            $file_config->code= "file_count_".$subDir;
            $file_config->value= 1;
        }
        $file_count= $file_config->value!=''?$file_config->value:1;

        $file_count+= 1;
        if($file_count>500)
        {
            $folder_count+= 1;
            $file_count= 1;

            $folder_config->value= $folder_count;
            $folder_config->save();
        }
        $file_config->value= $file_count;
        $file_config->save();

        if(!is_dir($this->config->application->imagesFolder.$subDir.'/'.$folder_count)){
            mkdir($this->config->application->imagesFolder.$subDir.'/'.$folder_count);
        }

        if($subDir=='video'){
            if(!is_dir($this->config->application->videosFolder.$folder_count)){
                mkdir($this->config->application->videosFolder.$folder_count);
            }

            /*if(!is_dir($this->config->application->storesFolder.$folder_count)){
                mkdir($this->config->application->storesFolder.$folder_count);
            }*/
        }

        return $folder_count;
    }

    public function objectArrayToAssoc($arr, $key, $val){
        $ret= array();
        if(is_array($arr)){

            foreach($arr as $k=>$v){
                if(is_object($v)){
                    $ret[(string) $v->{$key}]= $v->{$val};
                }
            }
        }
        return $ret;
    }

    public function getMongoId($ids){
        if(is_array($ids)){
            $arr= array();
            foreach($ids as $id){
                $arr[]= new \MongoDB\BSON\ObjectID($id);
            }
            return $arr;
        }elseif($ids!=''){
            return new \MongoDB\BSON\ObjectID($ids);
        }else{
            return null;
        }
    }

    /**
     * Validate the given ID from the __construct
     *
     * @return boolean true for valid / false for invalid.
     */
    public function isValidMongoId($id)
    {

        if(empty($id)){
            return false;
        }
        $regex = '/^[0-9a-z]{24}$/';
        if (class_exists("MongoId"))
        {
            try{
                $tmp = new \MongoDB\BSON\ObjectID($id);
                if ($tmp->{'$id'} == $id)
                {
                    return true;
                }
            }catch (Exception $e){
                return false;
            }
            return false;
        }

        if (preg_match($regex, $id))
        {
            return true;
        }
        return false;
    }

    public function castType($str){
        if($str==''){
            return $str;
        }elseif($str=='true' || $str=='false'){
            return (bool) $str;
        }elseif(is_numeric($str)){
            if(strpos($str, '.') === false){
                return (int) $str;
            }else{
                return (float) $str;
            }
        }

        return $str;
    }

    public function idToObject($model, $id, $multi=false){
        if(!empty($id) && $this->isValidMongoId($id)){
            if($multi){
                if(!is_array($id)){
                    $id= array($id);
                }

                $docs= $model::find(array(
                    'conditions' => array(
                        '_id' => array('$in' => $id)
                    )
                ));

                if($docs){
                    return $docs;
                }else{
                    return array();
                }
            }else{
                $doc= $model::findById($id);
                if(!empty($doc)){
                    return $doc;
                }else{
                    return new $model();
                }
            }
        }else{
            return new $model();
        }
    }

    public function redirect($uri = '')
    {
        if(substr($uri, 0, 7) == 'http://'){
            $url = $uri;
        }else{
            $url = '';

            $url = $this->config->application->baseUrl . $uri;
        }

        header('location: ' . $url);
    }

    public function checkEmail($email)
    {
        if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email))
            return false;
        else
            return true;
    }

    public function forward($uri = '')
    {

        if(empty($uri))
        {
            $controller = 'index';
            $action = 'index';
        }else{
            $params = explode("/", $uri);

            if(!isset($params[1]))
            {
                $action = 'index';
            }else{
                $action = $params[1];
            }

            $controller = $params[0];
        }

        $this->dispatcher->forward(array('controller' => $controller, 'action' =>$action));

    }

    public static function convertTime($seconds){
        if(empty($seconds)) return '';

        $duration = gmdate("H:i:s", $seconds);
        if(substr($duration, 0, 2) == '00')
        {
            $duration = substr($duration, 3, strlen($duration));
        }

        if(substr($duration, 0, 5) == '00:00')
        {
            $duration = substr($duration, 6, strlen($duration));
        }
        return $duration;
    }

    public function timestyle($timestamp){
        //type cast, current time, difference in timestamps
        $timestamp      = (int) $timestamp;
        $current_time   = time();
        $diff           = $current_time - $timestamp;

        //intervals in seconds
        $intervals      = array (
            'year' => 31556926, 'month' => 2629744, 'week' => 604800, 'day' => 86400, 'hour' => 3600, 'minute'=> 60
        );

        //now we just find the difference
        if ($diff == 0)
        {
            return 'Vừa mới gửi';
        }

        if ($diff < 60)
        {
            return $diff == 1 ? $diff . ' giây trước' : $diff . ' giây trước';
        }

        if ($diff >= 60 && $diff < $intervals['hour'])
        {
            $diff = floor($diff/$intervals['minute']);
            return $diff == 1 ? $diff . ' phút trước' : $diff . ' phút trước';
        }

        if ($diff >= $intervals['hour'] && $diff < $intervals['day'])
        {
            $diff = floor($diff/$intervals['hour']);
            return $diff == 1 ? $diff . ' giờ trước' : $diff . ' giờ trước';
        }

        if ($diff >= $intervals['day'] && $diff < $intervals['week'])
        {
            $diff = floor($diff/$intervals['day']);
            return $diff == 1 ? $diff . ' ngày trước' : $diff . ' ngày trước';
        }

        if ($diff >= $intervals['week'] && $diff < $intervals['month'])
        {
            $diff = floor($diff/$intervals['week']);
            return $diff == 1 ? $diff . ' tuần trước' : $diff . ' tuần trước';
        }

        if ($diff >= $intervals['month'] && $diff < $intervals['year'])
        {
            $diff = floor($diff/$intervals['month']);
            return $diff == 1 ? $diff . ' tháng trước' : $diff . ' tháng trước';
        }

        if ($diff >= $intervals['year'])
        {
            $diff = floor($diff/$intervals['year']);
            return $diff == 1 ? $diff . ' năm trước' : $diff . ' năm trước';
        }
    }

    public function bytetoSize($bytes, $precision = 2){
        $s_b = 'B';
        $s_kb = 'KB';
        $s_mb = 'MB';
        $s_gb = 'GB';
        $s_tb = 'TB';
        $kilobyte = 1024;
        $megabyte = $kilobyte * 1024;
        $gigabyte = $megabyte * 1024;
        $terabyte = $gigabyte * 1024;
        if ($bytes > 1024*1024*1024) $precision = 2;
        else if ($bytes > 1024*1024) $precision = 1;
        if (($bytes >= 0) && ($bytes < $kilobyte)) return $bytes . ' ' . $s_b;
        else if (($bytes >= $kilobyte) && ($bytes < $megabyte)) return number_format(($bytes / $kilobyte),$precision) . ' ' . $s_kb;
        else if (($bytes >= $megabyte) && ($bytes < $gigabyte))  return number_format(($bytes / $megabyte),$precision) . ' ' . $s_mb;
        else if (($bytes >= $gigabyte) && ($bytes < $terabyte))  return number_format(($bytes / $gigabyte),$precision) . ' ' . $s_gb;
        else if ($bytes >= $terabyte)  return number_format(($bytes / $terabyte),$precision) . ' ' . $s_tb;
        else  return $bytes . ' ' . $s_b;
    }

    public function randomString($length = 10, $options = array())
    {
        $characters = '';

        if(isset($options['only_number']) && $options['only_number'] == true){
            $characters .= '0123456789';
        }
        else{
            $characters .= '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        }

        if(isset($options['spacial_character']) && $options['spacial_character'] == true){
            $characters .= '<>?-_+={}[]~!@#$%^&*():;|';
        }

        return substr(str_shuffle($characters), 0, $length);
    }

    function stripExtraCharacter($s, $char=' ')
    {
        $newstr = "";

        for($i = 0; $i < strlen($s); $i++)
        {
            $newstr = $newstr . substr($s, $i, 1);
            if(substr($s, $i, 1) == $char)
                while(substr($s, $i + 1, 1) == $char)
                    $i++;
        }
        $newstr= ltrim($newstr);
        $newstr= rtrim($newstr);

        if(substr($newstr, 0, 1)==$char){
            $newstr= substr($newstr, 1);
        }

        if(substr($newstr, -1)==$char){
            $newstr= substr($newstr, 0, -1);
        }

        return $newstr;
    }

    public function createSlug($string, $split='-') {
        $string= $this->removeMarks($string);
        $trans = array ('&quot;'=>'-', "[" => "-", "]" => "-", "–" => "-", "'"=>"-", "‘"=>"-", "’"=>"-", "&quot;"=>"-", '“'=>'', '”'=>'-', '!'=>'-', '&'=>'-', '/'=>'-', '+'=>'-', '?'=>'-', "#"=>"-", "'"=> "-", ':'=>'-', "'" => '-', "'" => '-', '"' => '-', '"' => '-', ' ' => '-', '('=>'-', ')'=>'-', ','=>'-');
        $string= $this->stripExtraCharacter(strtr($string, $trans), $split);

//        return strtolower($string);
        return $string;
    }

    public function removeMarks($str) {
        $trans = array(
            "ă" => "a", "â" => "a", "á" => "a", "à" => "a", "ả" => "a", "ã" => "a", "ạ" => "a",
            "ấ" => "a", "ầ" => "a", "ẩ" => "a", "ẫ" => "a", "ậ" => "a",
            "ắ" => "a", "ằ" => "a", "ẳ" => "a", "ẵ" => "a", "ặ" => "a",
            "é" => "e", "è" => "e", "ẻ" => "e", "ẽ" => "e", "ẹ" => "e",
            "ế" => "e", "ề" => "e", "ể" => "e", "ễ" => "e", "ệ" => "e",
            "í" => "i", "ì" => "i", "ỉ" => "i", "ĩ" => "i", "ị" => "i",
            "ư" => "u", "ô" => "o", "ơ" => "o", "ê" => "e",
            "Ư" => "u", "Ô" => "o", "Ơ" => "o", "Ê" => "e",
            "ú" => "u", "ù" => "u", "ủ" => "u", "ũ" => "u", "ụ" => "u",
            "ứ" => "u", "ừ" => "u", "ử" => "u", "ữ" => "u", "ự" => "u",
            "ó" => "o", "ò" => "o", "ỏ" => "o", "õ" => "o", "ọ" => "o",
            "ớ" => "o", "ờ" => "o", "ở" => "o", "ỡ" => "o", "ợ" => "o",
            "ố" => "o", "ồ" => "o", "ổ" => "o", "ỗ" => "o", "ộ" => "o",
            "ú" => "u", "ù" => "u", "ủ" => "u", "ũ" => "u", "ụ" => "u",
            "ứ" => "u", "ừ" => "u", "ử" => "u", "ữ" => "u", "ự" => "u",
            'ý' => 'y', 'ỳ' => 'y', 'ỷ' => 'y', 'ỹ' => 'y', 'ỵ' => 'y',
            'Ý' => 'Y', 'Ỳ' => 'Y', 'Ỷ' => 'Y', 'Ỹ' => 'Y', 'Ỵ' => 'Y',
            "đ" => "d",
            "Đ" => "D",
            "Ă" => "A", "Â" => "A", "Á" => "A", "À" => "A", "Ả" => "A", "Ã" => "A", "Ạ" => "A",
            "Ấ" => "A", "Ầ" => "A", "Ẩ" => "A", "Ẫ" => "A", "Ậ" => "A",
            "Ắ" => "A", "Ằ" => "A", "Ẳ" => "A", "Ẵ" => "A", "Ặ" => "A",
            "É" => "E", "È" => "E", "Ẻ" => "E", "Ẽ" => "E", "Ẹ" => "E",
            "Ế" => "E", "Ề" => "E", "Ể" => "E", "Ễ" => "E", "Ệ" => "E",
            "Í" => "I", "Ì" => "I", "Ỉ" => "I", "Ĩ" => "I", "Ị" => "I",
            "Ư" => "U", "Ô" => "O", "Ơ" => "O", "Ê" => "E",
            "Ư" => "U", "Ô" => "O", "Ơ" => "O", "Ê" => "E",
            "Ú" => "U", "Ù" => "U", "Ủ" => "U", "Ũ" => "U", "Ụ" => "U",
            "Ứ" => "U", "Ừ" => "U", "Ử" => "U", "Ữ" => "U", "Ự" => "U",
            "Ó" => "O", "Ò" => "O", "Ỏ" => "O", "Õ" => "O", "Ọ" => "O",
            "Ớ" => "O", "Ờ" => "O", "Ở" => "O", "Ỡ" => "O", "Ợ" => "O",
            "Ố" => "O", "Ồ" => "O", "Ổ" => "O", "Ỗ" => "O", "Ộ" => "O",
            "Ú" => "U", "Ù" => "U", "Ủ" => "U", "Ũ" => "U", "Ụ" => "U",
            "Ứ" => "U", "Ừ" => "U", "Ử" => "U", "Ữ" => "U", "Ự" => "U",
        );

        $str = strtr($str, $trans);
        return $str;
    }

    public function guid(){
        if (function_exists('com_create_guid')){
            $uid = com_create_guid();
        }else{
            mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);// "-"
            $uid = chr(123)// "{"
                .substr($charid, 0, 8).$hyphen
                .substr($charid, 8, 4).$hyphen
                .substr($charid,12, 4).$hyphen
                .substr($charid,16, 4).$hyphen
                .substr($charid,20,12)
                .chr(125);// "}"

        }

        $uid = preg_replace("/[{}-]/","", $uid);
        return strtolower($uid);
    }

    public function get_rand_numbers($length = 10)
    {
        if($length>0)
        {
            $rand_id="";
            for($i=1; $i<=$length; $i++)
            {
                mt_srand((double)microtime() * 1000000);
                $num = mt_rand(27,36);
                $rand_id .= $this->assign_rand_value($num);
            }
        }
        return $rand_id;
    }

    protected function assign_rand_value($num)
    {
        // accepts 1 - 36
        switch($num)
        {
            case "1":
                $rand_value = "a";
                break;
            case "2":
                $rand_value = "b";
                break;
            case "3":
                $rand_value = "c";
                break;
            case "4":
                $rand_value = "d";
                break;
            case "5":
                $rand_value = "e";
                break;
            case "6":
                $rand_value = "f";
                break;
            case "7":
                $rand_value = "g";
                break;
            case "8":
                $rand_value = "h";
                break;
            case "9":
                $rand_value = "i";
                break;
            case "10":
                $rand_value = "j";
                break;
            case "11":
                $rand_value = "k";
                break;
            case "12":
                $rand_value = "l";
                break;
            case "13":
                $rand_value = "m";
                break;
            case "14":
                $rand_value = "n";
                break;
            case "15":
                $rand_value = "o";
                break;
            case "16":
                $rand_value = "p";
                break;
            case "17":
                $rand_value = "q";
                break;
            case "18":
                $rand_value = "r";
                break;
            case "19":
                $rand_value = "s";
                break;
            case "20":
                $rand_value = "t";
                break;
            case "21":
                $rand_value = "u";
                break;
            case "22":
                $rand_value = "v";
                break;
            case "23":
                $rand_value = "w";
                break;
            case "24":
                $rand_value = "x";
                break;
            case "25":
                $rand_value = "y";
                break;
            case "26":
                $rand_value = "z";
                break;
            case "27":
                $rand_value = "0";
                break;
            case "28":
                $rand_value = "1";
                break;
            case "29":
                $rand_value = "2";
                break;
            case "30":
                $rand_value = "3";
                break;
            case "31":
                $rand_value = "4";
                break;
            case "32":
                $rand_value = "5";
                break;
            case "33":
                $rand_value = "6";
                break;
            case "34":
                $rand_value = "7";
                break;
            case "35":
                $rand_value = "8";
                break;
            case "36":
                $rand_value = "9";
                break;
        }
        return $rand_value;
    }

    public function truncate($string, $limit = 100, $suffix = '...') {
        if (strlen($string) > $limit) {
            $string = htmlspecialchars_decode($string);
            $string = wordwrap($string, $limit);
            $string = substr($string, 0, strpos($string, "\n"));
            $string .= $suffix;
        }

        return $string;
    }

    /*paging*/
    public function getFrontendPaging($current_page= 1, $num_rows=0, $per_page=10, $action="?page={i}", $parameter_name='page', $show_first_last=true)
    {

        if(!($num_rows>0)) {
            return "";
        }

        //neu $action chua {i} thi action do user dat, neu khong tu sinh action
        $query_string= "";
        if($action!="" && stripos($action, "{i}")===false && $_SERVER['QUERY_STRING']!=''){
            $queries= $_SERVER['QUERY_STRING'];
            $queries= explode("&", $queries);
            foreach($queries as $query){
                $arr= explode("=", $query);
                if($arr[0]!="_url" && $arr[0]!=$parameter_name){
                    $query_string.= "{$arr[0]}=".(isset($arr[1])?$arr[1]:"")."&";
                }
            }

            $action= "?{$query_string}#{$parameter_name}{i}";
        }

        $limit_page= 10;

        //$current_page= isset($_REQUEST[$parameter_name])?$_REQUEST[$parameter_name]:1;

        $total_page= ceil($num_rows/$per_page); //tong pages

        $page_line="";
        $page_line.= '<ul class="pagination">';

        $start_page= 1;
        if($current_page>($limit_page/2))
            $start_page= $current_page-(int)($limit_page/2);
        if($total_page-$start_page<$limit_page)
            $start_page= $total_page-$limit_page;
        if($start_page<1)
            $start_page= 1;

        $end_page= $start_page+$limit_page;
        //if($start_page<)
        if($end_page>$total_page)
            $end_page= $total_page;

        if(($show_first_last)&($start_page>1)) {
            $page_line.='<li class="first"><a href="'.str_replace("{i}", "1", $action).'"><i class="fa fa-angle-double-left"></i></a></li>';
        }

        if($start_page>1) {
            $page_line.='<li class="prev"><a href="'.str_replace("{i}", $start_page-1, $action).'"><i class="fa  fa-angle-left"></i></a></li>';
        }

        // pages
        for($i=$start_page; $i<=$end_page; $i++) {
            if($i>$end_page) { break; }
            if($current_page!=$i) {
                $page_line.='<li><a href="'.str_replace("{i}", $i, $action).'">'.$i.'</a></li>';
            } else {
                $page_line.='<li class="active"><a onclick="return false" href="'.str_replace("{i}", $i, $action).'">'.$i.'</a></li>';
            }
        }

        // arrow next
        if($total_page>$end_page) {
            $page_line.='<li class="next"><a href="'.str_replace("{i}", $end_page+1, $action).'"><i class="fa fa-angle-right"></i></a></li>';
        }

        // arrow last
        if(($show_first_last)&($total_page>$end_page)) {
            $page_line.='<li class="last"><a href="'.str_replace("{i}", $total_page, $action).'"><i class="fa fa-angle-double-right"></i></a></li>';
        }

        $page_line.= '</ul>';

        return $page_line;
    }

    /*paging*/
    public function getPaging($num_rows=0, $per_page=10, $frmID='#gridForm', $action="", $parameter_name='page', $show_first_last=true)
    {
        if(!($num_rows>0)) {
            return "";
        }

        //neu $action chua {i} thi action do user dat, neu khong tu sinh action
        $query_string= "";
        if($action!="" && stripos($action, "{i}")===false && $_SERVER['QUERY_STRING']!=''){
            $queries= $_SERVER['QUERY_STRING'];
            $queries= explode("&", $queries);
            foreach($queries as $query){
                $arr= explode("=", $query);
                if($arr[0]!="_url" && $arr[0]!=$parameter_name){
                    $query_string.= "{$arr[0]}=".(isset($arr[1])?$arr[1]:"")."&";
                }
            }

            $action= "?{$query_string}#{$parameter_name}{i}";
        }

        $limit_page= 4;

        $current_page= isset($_REQUEST[$parameter_name])?$_REQUEST[$parameter_name]:1;

        $total_page= ceil($num_rows/$per_page); //tong pages

        $page_line="";
        $page_line.= '<ul class="pagination">';

        $start_page= 1;
        if($current_page>($limit_page/2))
            $start_page= $current_page-(int)($limit_page/2);
        if($total_page-$start_page<$limit_page)
            $start_page= $total_page-$limit_page;
        if($start_page<1)
            $start_page= 1;

        $end_page= $start_page+$limit_page;
        //if($start_page<)
        if($end_page>$total_page)
            $end_page= $total_page;

        if(($show_first_last)&&($start_page>1)) {
            $page_line.='<li><a class="first" href="'.str_replace("{i}", "1", $action).'" onclick="$(\''.$frmID.'\').trigger(\'submit\', ['.(1).']); return false;"><i class="fa fa-angle-double-left"></i></a></li>';
        }

        if($start_page>1) {
            $page_line.='<li><a class="first" href="'.str_replace("{i}", $start_page-1, $action).'" onclick="$(\''.$frmID.'\').trigger(\'submit\', ['.($start_page-1).']); return false;"><i class="fa fa-angle-left"></i></a></li>';
        }

        // pages
        for($i=$start_page; $i<=$end_page; $i++) {
            if($i>$end_page) { break; }
            if($current_page!=$i) {
                $page_line.='<li><a href="'.str_replace("{i}", $i, $action).'" onclick="$(\''.$frmID.'\').trigger(\'submit\', ['.($i).']); return false;">'.$i.'</a></li>';
            } else {
                $page_line.='<li class="active"><a href="" onclick="return false;">'.$i.'</a></li>';
            }
        }

        // arrow next
        if($total_page>$end_page) {
            $page_line.='<li><a class="first" href="'.str_replace("{i}", $end_page+1, $action).'" onclick="$(\''.$frmID.'\').trigger(\'submit\', ['.($end_page+1).']); return false;"><i class="fa fa-angle-right"></i></a></li>';
        }

        // arrow last
        if(($show_first_last)&&($total_page>$end_page)) {
            $page_line.='<li><a class="first" href="'.str_replace("{i}", $total_page, $action).'" onclick="$(\''.$frmID.'\').trigger(\'submit\', ['.($total_page).']); return false;"><i class="fa fa-angle-double-right"></i></a></li>';
        }

        $page_line.= '</ul>';
        return $page_line;
    }

    function sendMail($email, $subject, $body, $params=array())
    {
        require __DIR__.'/PHPMailer/PHPMailerAutoload.php';

        $mail = new PHPMailer;
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup server
        $mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
        $mail->Port = 587;
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'thuc.ngo@netlink.vn';                            // SMTP username
        $mail->Password = 'ltv.vn@123';                           // SMTP password

        $mail->CharSet	=	'utf-8';
        $mail->From = 'meme@netlink.vn';
        $mail->FromName = 'Meme Videos Viral Network';

        $mail->addAddress($email);               // Name is optional

        if(isset($params['replyTo']))
            $mail->addReplyTo($params['replyTo']);

        if(isset($params['ccEmails']) and is_array($params['ccEmails']) && count($params['ccEmails'])>0)
        {
            foreach($params['ccEmails'] as $k=>$v)
                $mail->addCC($v);
        }

        if(isset($params['bccEmails']) and is_array($params['bccEmails']) && count($params['bccEmails'])>0)
        {
            foreach($params['bccEmails'] as $k=>$v)
                $mail->addBCC($v);
        }

        if(isset($params['attachments']) and is_array($params['attachments']) && count($params['attachments'])>0)
        {
            foreach($params['attachments'] as $k=>$v)
                $mail->addAttachment($v);         // Add attachments
        }

        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);

        if($mail->send()) {
            return true;
        }else{
            echo 'Mailer Error: ' . $mail->ErrorInfo;

            return false;
        }
    }

    function arrayToObject(array $array, $className='stdClass') {
        return unserialize(sprintf(
            'O:%d:"%s"%s',
            strlen($className),
            $className,
            strstr(serialize($array), ':')
        ));
    }

    function objectToObject($instance, $className='stdClass') {
        return unserialize(sprintf(
            'O:%d:"%s"%s',
            strlen($className),
            $className,
            strstr(strstr(serialize($instance), '"'), ':')
        ));
    }

    public function getVideosByCate($idCate)
    {
        $conditions= array();
        if($idCate!=''){
            $conditions["categories_ids"]= new \MongoId($idCate);
            $videos= \Videos::find(array(
                'conditions' => $conditions,
                'sort' => array('title' => 1),
                'limit'=>'4'
            ));
            if($videos)
                return $videos;
        }

        return array();
    }

    public function getChannelsByChannelGenres($id)
    {
        $conditions= array();
        if($id!=''){
            $conditions["genres_ids"]= new \MongoId($id);
            $conditions["state"]    = 1;
            $channels = \Channels::find(array(
                'conditions' => $conditions,
                'sort' => array('title' => 1),
                'limit'=>'4'
            ));
            if($channels)
                return $channels;
        }

        return array();
    }

    public function check_is_shared_video($channels_id, $user_id)
    {

        if(empty($channels_id) || empty($user_id) ) return 0;

        $doc= \Channels::findById($channels_id);

        if(empty($doc) || $doc->is_access_shared_video == 0)
            return 0;

        if((string)$doc->users_id == (string)$user_id)
        {
            return 1;
        }
        else
        {
            if(count($doc->members) > 0)
            {
                foreach($doc->members as $k=>$v)
                {
                    if((string)$v['users_id'] == (string)$user_id)
                    {
                        if(!empty($v['is_access_shared_video']) && $v['is_access_shared_video'] == 1)
                        {
                            return 1;
                        }
                        else{return 0;}
                    }
                }
            }

            return 0;
        }
    }

    public function get_location($conditions = array())
    {
        $docs = \Notifies::find(array(
                'conditions' => $conditions
            )
        );

        if($this->session->get('user'))
            $userId = $this->session->get('user')->getId();
        $total = 0;
        if(!empty($docs) && count($docs) > 0)
            foreach($docs as $k=>$v){
                foreach($v->receivers as $k2=>$v2){
                    if($v2==$userId && $v->receiverReads[$k2] == 0)
                    {
                        $total++;
                    }
                }
            }
        return $total;
    }

    public function get_notify($conditions = array())
    {
        $docs = \Notifies::find(array(
                'conditions' => $conditions
            )
        );

        if($this->session->get('user'))
            $userId = $this->session->get('user')->getId();
        $total = 0;
        $result = array();
        if(!empty($docs) && count($docs) > 0)
            foreach($docs as $k=>$v){
                $tmp = $this->helper->idToObject('Users', $v->sender);
                $tmp_avatar = $this->config->application->imagesThumbServer.'user/avatar/default.png';
                if(!empty($tmp->avatar) && $tmp->avatar!='')
                    $tmp_avatar = $this->config->application->imagesThumbServer.'user/avatar/'.$tmp->avatar;
                $timeElapsed = $this->helper->timestyle($v->created);
                if(empty($v->videos_id))
                    $url = $this->url->get('notify/view').'?id='.(string)$v->_id;
                else
                    $url = $this->url->get('video/detail').'?id='.(string)$v->videos_id;
                foreach($v->receivers as $k2=>$v2){
                    if($v2==$userId && $v->receiverReads[$k2] == 0)
                    {
                        $total++;
                        $result[] = array(
                            'id'        => (string)$v->_id,
                            'videos_id' => (string)$v->videos_id,
                            'subject'   => $v->subject,
                            'content'   => $v->content,
                            'url'       => $url,
                            'sender'    => $tmp->fullname,
                            'avatar'    => $tmp_avatar,
                            'timeElapsed'   => $timeElapsed
                        );
                    }
                }
                if($total == 5)
                    return $result;
            }
        return $result;
    }

    public function check_access_permission($controller='', $action='', $object=array(), &$redirect=null)
    {
        switch($controller) {
            case 'video':
                if($action=='edit'||$action=='delete')
                {
                    if($object->channels_id != $this->session->get('channels_id'))
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa video '".$object->title."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }

                    if($this->session->get('user')->group=='4' && $object->users_id != $this->session->get('user')->getId())
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa video '".$object->title."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }
                }
                break;
            case 'user':
                if($action=='edit'||$action=='delete')
                {
                    $listMember = array();
                    $channel = \Channels::findById((string)$this->session->get('channels_id'));
                    $listMember[] = ($channel)?$channel->users_id:'';
                    $memberChannel = ($channel)?$channel->members:array();
                    foreach($memberChannel as $k=>$v)
                    {
                        $listMember[] = $v['users_id'];
                    }

                    if(!in_array($object->getId(),$listMember))
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa thành viên '".$object->fullname."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }

                    if($this->session->get('user')->group=='4' && $object->getId() != $this->session->get('user')->getId())
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa thành viên '".$object->fullname."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }
                }
                break;
            case 'channel':
                if($action=='edit')
                {
                    $channels = \Channels::find(array('conditions' => array('users_id'=>$this->session->get('user')->getId())));
                    $listChannel = array();
                    foreach($channels as $k=>$v)
                    {
                        $listChannel[] = $v->getId();
                    }

                    if(!in_array($object->getId(),$listChannel))
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa channel '".$object->title."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }
                }
                break;
            case 'channelcategory':
                if($action=='edit'||$action=='delete')
                {
                    $conditions = array();
                    if($this->session->get('user')->group=='5')
                    {
                        $conditions = array('users_id'=>$this->session->get('user')->getId());
                    }
                    elseif($this->session->get('user')->group=='4')
                    {
                        $conditions = array('members.users_id'=>$this->session->get('user')->getId());
                    }

                    $channels = \Channels::find(array('conditions' => $conditions));
                    $listChannel = array();
                    foreach($channels as $k=>$v)
                    {
                        $listChannel[] = $v->getId();
                    }

                    if(!in_array($object->channels_id,$listChannel))
                    {
                        $this->getDI()->get('flash')->error("Bạn không có quyền chỉnh sửa chuyên mục '".$object->title."'");
                        $redirect = $this->response->redirect("");
                        return false;
                    }
                }
                break;
        }

        return true;
    }

    public function getAction($path, $params= array())
    {


        $path= explode('/', $path);
        $controller= !empty($path[0])?$path[0]:'index';

        $class= ucfirst($controller).'Controller';
        $obj= new $class;

        $action= !empty($path[1])?$path[1]:'index';

        $widget= $action.'Action';
        $obj->{$widget}($params);

        $this->getDI()->get('view')->partial($controller.'/'.$action);

        /*$dispatcher->setControllerName($controller);

        $dispatcher->setActionName($action);

		$params= array('a' => 'xxx');
        $dispatcher->setParams($params);

        $dispatcher->dispatch();

        //var_dump($dispatcher);

        $response = $dispatcher->getReturnedValue();
        //var_dump($dispatcher); exit();


        if($response instanceof \Phalcon\Http\ResponseInterface) {
            echo $response->getContent();
        }

        echo $response;*/
    }

    public function getListSubComment($reply_comments_ids)
    {
        $reply_comments_ids = array_reverse($reply_comments_ids);
        $listComment = '';
        foreach($reply_comments_ids as $k=>$v)
        {
            $comment = \Comments::findById($v);
            if(!empty($comment))
            {
                $userComment = $this->helper->idToObject('Users',$comment->users_id);
                $userAvatarComment = !empty($userComment->avatar)? $this->config->application->imagesThumbServer.'/user/avatar/'.$userComment->avatar:$this->config->application->imagesThumbServer.'user/avatar/default.png';
                $userName = $userComment!=null?$userComment->fullname:'';
                $idHidden = (string)$comment->getId();
                $link = $this->url->get('user').'?u='.$userComment->getId();

                $user = $this->session->get('user');
                $userAvatar = !empty($user->avatar)? $this->config->application->imagesThumbServer.'/user/avatar/'.$user->avatar:$this->config->application->imagesThumbServer.'user/avatar/default.png';
                $userSession = !empty($user)?(string)$user->getId():'';
                $likeActive = empty($user)||!in_array($user->getId(),$comment->like_users_ids)?'':'active';
                $like = empty($user)||!in_array($user->getId(),$comment->like_users_ids)?'Like':'Unlike';
                $likeThump = empty($user)||!in_array($user->getId(),$comment->like_users_ids)?'fa-thumbs-up':'fa-thumbs-down';

                $content = '';

                $getStateComment = $this->helper->getStateComment((string)$comment->getId(),(string)$userComment->getId(),$userSession);
                if($getStateComment=='Public'){
                    $content = $comment->content;
                }else if($getStateComment=='Waiting'){
                    $content = '<span>'.$comment->content.'</span> <span style="color:#D01040;font-size:11px;font-style:italic;"> (Comment đang chờ duyệt)</span>';
                }

                if($getStateComment!='UnPublic'){
                    $timeStyle = $this->helper->timestyle($comment->created);

                    if($this->session->get('user')){
                        $editButton = '';
                        $deleteButton = '';
                        $styleDelete = '';
                        $checkMore = '';
                        $unDeleted = '';

                        if(((string)$user->getId())==(string)$comment->users_id)
                        {
                            $editButton = '<li><a style="cursor:pointer" onClick="editOnClick($(this),$(this).closest(\'.comment-line-on-sub\').find(\'.comment-edit-hidden-'.$idHidden.'\'))" class="comment-btn"><span class="fa fa-pencil"></span>Edit</a></li>';
                            $checkMore = '<a class="comment-btn" data-toggle="dropdown" href="#">More <b class="caret"></b></a>';
                        }
                        if((((string)$this->session->get('user')->getId())==(string)$comment->users_id)&&($comment->deleted==0))
                        {
                            $deleteButton = '<li><a style="cursor:pointer" onClick="deleteOnClick($(this),$(this).closest(\'.comment-line-sub\').find(\'.comment-hidden\').val())" class="comment-btn"><span class="fa fa-times"></span>Delete</a></li>';
                        }
                        if($comment->deleted==1)
                        {
                            $content = '(comment đã xóa)';
                            $styleDelete = 'style="color:#9F9F9F"';
                        }
                        if(($comment->deleted==1)&&(!empty($user)&&((string)$comment->users_id==((string)$user->getId()))))
                        {
                            $unDeleted = '<a style="cursor:pointer;text-decoration:underline;" onClick="unDeletedOnClick($(this),$(this).closest(\'.comment-line-sub\').find(\'.comment-hidden\').val())"> Undeleted</a>';
                        }
                        $listComment .= '<a href="#" name="comment'.$idHidden.'"></a>
                        <div class="comment-line-sub comment-line-on-sub">
                            <input type="hidden" class="comment-hidden" value="'.$idHidden.'">
                            <input type="hidden" class="comment-content" value="'.$comment->content.'">
                            <a href="'.$link.'"><img class="comment-user" src="'.$userAvatarComment.'"></a>
                            <div class="comment-text">
                                <a href="'.$link.'" class="comment-user-name">'.$userName.'</a>
                                <span class="dot"></span> <span class="comment-time">'.$timeStyle.'</span>
                                <p '.$styleDelete.' class="comment-review">'.$content.$unDeleted.'</p>
                                <div class="dropdown">
                                    <a style="cursor:pointer" class="comment-btn '.$likeActive.'" onclick="likeComment($(this),$(this).closest(\'.comment-line-sub\').find(\'.comment-hidden\').val());"><span class="fa '.$likeThump.'"></span><span style="margin:0" class="span-like-string">'.$like.'</span> (<span style="margin:0" class="span-like-number">'.count($comment->like_users_ids).'</span>)</a>';
                        if(empty($unDeleted)){
                            $listComment .= '<span class="commentMore">'.$checkMore.'
                                    <ul class="dropdown-menu">
                                    '.$editButton.'
                                    '.$deleteButton.'
                                    </ul>
                                </span>';
                        }
                        $listComment .= '</div>
                            </div>
                            <div class="comment-edit-hidden-'.$idHidden.' comment-line-sub" style="display:none">
                                <a href="'.$link.'" class="hidden-xs"><img class="comment-user" src="'.$userAvatar.'"></a>
                                <div class="comment-form">
                                    <input class="comment-input form-control comment-input-sub" onkeypress="if(event.keyCode==13){editCommentButtonOnclick($(this),$(this).closest(\'.comment-form\').find(\'.comment-input\').val(),$(this).closest(\'.comment-line-on-sub\').find(\'.comment-hidden\').val());}" placeholder="write your comment..." />
                                    <button type="submit" onClick="editCommentButtonOnclick($(this),$(this).closest(\'.comment-form\').find(\'.comment-input\').val(),$(this).closest(\'.comment-line-on-sub\').find(\'.comment-hidden\').val());" class="btn btn-comment-form-sub">Edit</button>
                                </div>
                            </div>
                        </div>';
                    }else{
                        $listComment .= '<a href="#" name="comment'.$idHidden.'"></a>
                        <div class="comment-line-sub comment-line-on-sub">
                            <input type="hidden" class="comment-hidden" value="'.$idHidden.'">
                            <input type="hidden" class="comment-content" value="'.$content.'">
                            <a href="'.$link.'"><img class="comment-user" src="'.$userAvatarComment.'"></a>
                            <div class="comment-text">
                                <a href="'.$link.'" class="comment-user-name">'.$userName.'</a>
                                <span class="dot"></span> <span class="comment-time">'.$timeStyle.'</span>
                                <p class="comment-review">'.$content.'</p>
                                <p>
                                    <a style="cursor:pointer" class="comment-btn '.$likeActive.'" onclick="return setAction({\'action\': \'likecomment\',\'commentId\':\''.$idHidden.'\'});" data-toggle="modal" data-target="#loginPopup"><span class="fa '.$likeThump.'"></span><span style="margin:0" class="span-like-string">'.$like.'</span> (<span style="margin:0" class="span-like-number">'.count($comment->like_users_ids).'</span>)</a>
                                </p>
                            </div>
                            <div class="comment-input-hidden-'.$idHidden.' comment-line-sub" style="display:none">
                                <a href="'.$link.'" class="hidden-xs"><img class="comment-user" src="'.$userAvatar.'"></a>
                                <div class="comment-form">
                                    <input class="comment-input form-control comment-input-sub" data-toggle="modal" data-target="#loginPopup" placeholder="write your comment..." />
                                    <button type="submit" data-toggle="modal" data-target="#loginPopup" class="btn btn-comment-form-sub">Comment</button>
                                </div>
                            </div>
                        </div>';
                    }
                }
            }
        }
        return $listComment;
    }

    public function getStateComment($idComment,$idUserComment,$idUserLogin)
    {
        $comment = \Comments::findById($idComment);
        $userLogin = !empty($idUserLogin)?\Users::findById($idUserLogin):'';
        if($comment->state==1)
        {
            return 'Public';
        }
        else if(!empty($userLogin)&&((trim($idUserComment)==trim($idUserLogin))||($userLogin->group==6)))
        {
            return 'Waiting';
        }
        else
        {
            return 'UnPublic';
        }
    }

    public function getListCommentStatus($comments_status_id)
    {
        $listComment = '';

        $channelStatusComments = \ChannelStatusComments::find(array('conditions'=>array('channel_status_id' => new \MongoId($comments_status_id)),'sort'=>array('created'=>-1),'limit'=>3));

        foreach($channelStatusComments as $k=>$v)
        {
            $userComment = $this->helper->idToObject('Users',$v->users_id);
            $userAvatar = !empty($userComment->avatar)? $this->config->application->imagesThumbServer.'/user/avatar/'.$userComment->avatar:$this->config->application->imagesThumbServer.'user/avatar/default.png';
            $userName = $userComment!=null?$userComment->fullname:'';
            $link = $this->url->get('user').'?u='.$userComment->getId();

            $user = $this->session->get('user');
            $like =(empty($user)||!in_array($user->getId(),$v->like_users_ids)?'Like':'Unlike');
            $thump =(empty($user)||!in_array($user->getId(),$v->like_users_ids)?'fa-thumbs-up':'fa-thumbs-down');

            $timeStyle = $this->helper->timestyle($v->created);

            $commentSendonClick = ($this->session->get('user'))?'onclick="likeCommentStatus($(this),$(this).closest(\'.line-comment-rs\').find(\'.hidden_comment_status\').val())"':' onclick="return setAction({\'action\': \'likecommentstatus\',\'commentStatusId\':\''.$v->getId().'\'});" data-toggle="modal" data-target="#loginPopup"';

            $listComment .= '<div class="line-comment-rs">
                                <input type="hidden" class="hidden_comment_status" value="'.$v->getId().'">
                                <img class="img-comment-rs" src="'.$userAvatar.'" />
                                <div class="feed-comment-rs">
                                    <p><a href="'.$link.'" class="name-comment-rs">'.$userName.'</a> '.$v->content.' </p>
                                    <p><span class="time-comment-rs">'.$timeStyle.'</span> <a style="cursor:pointer" '.$commentSendonClick.' class="btn-comment-like"><span class="span-status-like">'.$like.'</span></a> <a style="cursor:pointer" '.$commentSendonClick.' class="btn-list-like"><i class="fa '.$thump.'"></i> <span class="count-status-like">'.count($v->like_users_ids).'</span></a></p>
                                </div>
                            </div>';

        }
        return $listComment;
    }
    function getpagingArray($input, $total, $page, $litmit) {
        $start = ($page-1) * $litmit;
        $end = $start + $litmit;

        // Conditionally return results
        if ($start < 0 || $total <= $start)
            // Page is out of range
            return array();
        else if ($total <= $end)
            // Partially-filled page
            return array_slice($input, $start);
        else
            // Full page
            return array_slice($input, $start, $end - $start);
    }
    public function getCommentStatusLeft($comments_status_id)
    {
        $channelStatusComments = \ChannelStatusComments::find(array('conditions'=>array('channel_status_id' => new \MongoId($comments_status_id)),'sort'=>array('created'=>-1),'skip'=>3));
        return count($channelStatusComments);
    }

    function mahoa($sValue)
    {
        $result = rtrim(
            base64_encode(
                mcrypt_encrypt(
                    MCRYPT_RIJNDAEL_256,
                    $this->config->application->secretkey, $sValue,
                    MCRYPT_MODE_ECB,
                    mcrypt_create_iv(
                        mcrypt_get_iv_size(
                            MCRYPT_RIJNDAEL_256,
                            MCRYPT_MODE_ECB
                        ),
                        MCRYPT_RAND)
                )
            ), "\0"
        );
        $trans = array('+' => '_._');
        return strtr($result, $trans);
    }

    function giaima($sValue)
    {
        $trans = array('_._' => '+');
        $sValue = strtr($sValue, $trans);
        return rtrim(
            mcrypt_decrypt(
                MCRYPT_RIJNDAEL_256,
                $this->config->application->secretkey,
                base64_decode($sValue),
                MCRYPT_MODE_ECB,
                mcrypt_create_iv(
                    mcrypt_get_iv_size(
                        MCRYPT_RIJNDAEL_256,
                        MCRYPT_MODE_ECB
                    ),
                    MCRYPT_RAND
                )
            ), "\0"
        );
    }
}
