<?php
namespace TungDzShopPhanlconv1\Models;

class Users extends BaseCollection
{
    public $modules;

    public $email;

    public $phone;

    public $password;

    public $token;
    public $token_device;

    public $fullname;

    public $gender = 1;

    public $avatar = '';

    public $dob;

    public $state = false;
    public $managed_id;
    public $taikhoanchinh= false;
    public $province;
    public $sodienthoai;

	public $permisions=array(); //array('controllerName'=>array('actionName1', 'actionName2'))


}
