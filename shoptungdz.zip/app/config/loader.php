<?php

use Phalcon\Loader;

$loader = new Loader();
/**
 * We're a registering a set of directories taken from the configuration file
 */
/**
 * Register Namespaces
 */
$loader->registerNamespaces([
    'TungDzShopPhanlconv1\Models' => APP_PATH . '/common/models/',
    'Phalcon' => APP_PATH.'/common/library/ Phalcon/',
]);

/**
 * Register module classes
 */
$loader->registerClasses([
    'TungDzShopPhanlconv1\Modules\Frontend\Module' => APP_PATH . '/modules/frontend/Module.php',
    'TungDzShopPhanlconv1\Modules\Admin\Module' => APP_PATH . '/modules/admin/Module.php'
]);


/* start: handle loader event */
$eventsManager = new \Phalcon\Events\Manager();
//Listen all the loader events
$eventsManager->attach('loader', function($event, $loader) {
    if ($event->getType() == 'beforeCheckPath') {
        //echo $loader->getCheckedPath();
    }
});
$loader->setEventsManager($eventsManager);
/* end: handle loader event */

$loader->registerDirs(
    [
        $config->application->controllersDir,
        $config->application->modelsDir
    ]
);
$loader->register();
