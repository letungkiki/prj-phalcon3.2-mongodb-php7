<?php

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{
	public function afterExecuteRoute($dispatcher)
	{
		$this->view->title= $this->title;
		$this->view->settings= $this->settings;
		$this->grid= $this->view->grid= $this->session->get("grid")[$this->dispatcher->getControllerName()];
	}

	public function debug($var)
	{
		$this->dump($var);
		exit();
	}

	public function dump($var)
	{
		echo "<pre>";
		print_r($var);
		echo "<pre>";
	}
}
