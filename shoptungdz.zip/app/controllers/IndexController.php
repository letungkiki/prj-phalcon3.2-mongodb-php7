<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {
    	 $this->debug($this->mongo);
    }

}

