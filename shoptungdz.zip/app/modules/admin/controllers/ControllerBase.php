<?php
namespace TungDzShopPhanlconv1\Modules\Admin\Controllers;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{
    public $title = '';

    public function initialize()
    {

    }

    public function beforeExecuteRoute($dispatcher)
    {
//        if($this->dispatcher->getControllerName()!= 'account'){
//            $user = $this->getDI()->getSession()->get('user');
//            if (empty($user)) {
//                $this->getDI()->get('flash')->error('Bạn phải đăng nhập để truy cập trang này');
//                header('location: ' . $this->getDI()->get('config')->application->baseUri . 'account/login');
//                exit();
//            } elseif ($user->group != $this->dispatcher->getModuleName()) {
//                $this->getDI()->get('flash')->error = 'Bạn không có quyền truy cập trang này';
//                header('location: ' . $this->getDI()->get('config')->application->baseUri . 'account/login');
//                exit();
//            }
//        }
//        $this->view->breadcums= $this->breadcums;
//
//        $this->view->controller= $this->dispatcher->getControllerName();
//        $this->view->action= $this->dispatcher->getActionName();
//
//        $menus = include($this->config->application->appDir.'common/danhmucs/menus.php');
//        $this->view->menus= $menus['admin'];
//        $this->view->settings= include($this->config->application->appDir.'common/danhmucs/setting.php');
//
//        $grid= $this->session->get("grid");
//        if(empty($grid)){
//            $grid= array();
//        }
//
//        if($this->request->isAjax()) {
//            $grid[$this->dispatcher->getControllerName()]= $_POST;
//            $this->session->set("grid", $grid);
//
//            $this->grid= $grid;
//
//            $this->view->disableLevel(\Phalcon\Mvc\View::LEVEL_MAIN_LAYOUT);
//        }

        //var_dump($grid); die;

    }

    public function afterExecuteRoute($dispatcher)
    {
//        $this->view->title= $this->title;
//        $this->view->settings= $this->settings;
//        $this->grid= $this->view->grid= $this->session->get("grid")[$this->dispatcher->getControllerName()];
    }

    public function debug($var)
    {
        $this->dump($var);
        exit();
    }

    public function dump($var)
    {
        echo "<pre>";
        print_r($var);
        echo "<pre>";
    }
}
