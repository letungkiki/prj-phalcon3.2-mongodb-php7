<?php
namespace TungDzShopPhanlconv1\Modules\Frontend\Controllers;

class IndexController extends ControllerBase
{

    public function indexAction()
    {
    	 $this->debug($this->mongo);
    }

}

